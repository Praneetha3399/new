import java.nio.charset.Charset;
import java.util.Arrays;

public class StringEx {
		

	public static void main(String[] args) {
		
		 String s="Sachin";  
		 s=s.concat(" Tendulkar"); 
		 System.out.println(s);
		 
		 String text= new String("Hello, My name is Sachin"); 
		 String[] sentences = text.split(",");  
	        System.out.println(Arrays.toString(sentences));  
	        
	        String s1="Sachin";    
	        System.out.println(s1.toUpperCase()); 
	        System.out.println(s1.toLowerCase());
	        System.out.println(s1);
	        
	        int a=10;    
	        String s2=String.valueOf(a);    
	        System.out.println(s2+10);   
	        
	        byte[] bArr = {99, 114, 108, 102, 102};
	        Charset ch = Charset.defaultCharset();
	        System.out.println(ch);
	        String str = new String(bArr, 1, 3);
	        System.out.println(str);
	        
	}
}
